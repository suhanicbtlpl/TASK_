import { mode } from "@chakra-ui/theme-tools";
export const globalStyles = {
  colors: {
    brand: {
      50: "#f0f4ff",
      100: "#d9e2ff",
      200: "#b9c9ff",
      300: "#8ca8ff",
      400: "#5a7eff",
      500: "#4318FF", // Primary Brand Color: Vibrant Indigo
      600: "#3412cc",
      700: "#2710a0",
      800: "#200e80",
      900: "#0b1437",
    },
    // Modern balanced palettes
    premium: {
      gold: "#C5A059",
      silver: "#A7A7A7",
      navy: "#111C44",
      glass: "rgba(255, 255, 255, 0.08)"
    },
    secondaryGray: {
      100: "#E0E5F2",
      200: "#E1E9F8",
      300: "#F4F7FE",
      400: "#E9EDF7",
      500: "#8F9BBA",
      600: "#A3AED0",
      700: "#707EAE",
      800: "#47548A",
      900: "#1B2559",
    },
  },
  styles: {
    global: (props) => ({
      body: {
        overflowX: "hidden",
        bg: mode("#F4F7FE", "navy.900")(props),
        fontFamily: "'Outfit', sans-serif", // More modern font
        letterSpacing: "-0.2px",
        color: mode("secondaryGray.900", "white")(props),
      },
      "::-webkit-scrollbar": {
        width: "8px",
      },
      "::-webkit-scrollbar-track": {
        background: "transparent",
      },
      "::-webkit-scrollbar-thumb": {
        background: mode("#cbd5e0", "#4A5568")(props),
        borderRadius: "10px",
      },
      input: {
        color: "gray.700",
      },
    }),
  },
};
