import React, { useState, useEffect } from "react";
import { Box, Flex, Text, useColorModeValue } from "@chakra-ui/react";
import TableActivityLog from "views/admin/activityLog/components/TableActivityLog";
import Card from "components/card/Card.js";
import { logService } from "services/api";
import { createColumnHelper } from "@tanstack/react-table";
import { format } from "date-fns";

const columnHelper = createColumnHelper();

export default function ActivityLog() {
  const [logData, setLogData] = useState([]);
  const [loading, setLoading] = useState(true);

  const textColor = useColorModeValue('secondaryGray.900', 'white');
  const textColorSecondary = 'gray.400';

  const columnsData = [
    columnHelper.accessor('name', {
      id: 'name',
      header: 'NAME',
      cell: (info) => (
        <Text color={textColor} fontSize="sm" fontWeight="700">
          {info.getValue()}
        </Text>
      ),
    }),
    columnHelper.accessor('email', {
      id: 'email',
      header: 'EMAIL',
      cell: (info) => (
        <Text color={textColorSecondary} fontSize="sm" fontWeight="500">
          {info.getValue()}
        </Text>
      ),
    }),
    columnHelper.accessor('role', {
      id: 'role',
      header: 'ROLE',
      cell: (info) => (
        <Text color={textColorSecondary} fontSize="sm" fontWeight="500">
          {info.getValue()}
        </Text>
      ),
    }),
    columnHelper.accessor('timestamp', {
      id: 'timestamp',
      header: 'TIMESTAMP',
      cell: (info) => {
        const date = new Date(info.getValue());
        return (
          <Text color={textColorSecondary} fontSize="sm" fontWeight="500">
            {isNaN(date.getTime()) ? info.getValue() : format(date, 'MMM dd, yyyy HH:mm:ss')}
          </Text>
        );
      },
    }),
    columnHelper.accessor('action', {
      id: 'action',
      header: 'ACTION',
      cell: (info) => (
        <Text color={textColorSecondary} fontSize="sm" fontWeight="600" textTransform="uppercase">
          {info.getValue()}
        </Text>
      ),
    }),
  ];

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await logService.getAll();
        setLogData(data);
      } catch (err) {
        console.error("Error fetching activity logs:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <Box pt={{ base: "130px", md: "80px", xl: "80px" }}>
      <Card px="0px" pb="20px">
        {loading ? (
          <Flex justify="center" align="center" minH="200px">
            <Text fontSize="xl" fontWeight="600" color="gray.400">
              Gathering audit logs...
            </Text>
          </Flex>
        ) : (
          <TableActivityLog logData={logData} columnsData={columnsData} />
        )}
      </Card>
    </Box>
  );
}
