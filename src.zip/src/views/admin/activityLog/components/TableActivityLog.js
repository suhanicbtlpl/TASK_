import React, { useState } from 'react';
import {
  Box,
  Flex,
  Table,
  Tbody,
  Td,
  Text,
  Th,
  Thead,
  Tr,
  useColorModeValue,
} from '@chakra-ui/react';
import {
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  useReactTable,
} from '@tanstack/react-table';

export default function TableActivityLog({ logData, columnsData }) {
  const [sorting, setSorting] = useState([]);
  const textColor = useColorModeValue('secondaryGray.900', 'white');
  const borderColor = useColorModeValue('gray.200', 'whiteAlpha.100');

  const table = useReactTable({
    data: logData,
    columns: columnsData,
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
  });

  return (
    <Box>
      <Flex
        align="center"
        justify="space-between"
        w="100%"
        px="25px"
        py="20px"
        borderBottom="1px solid"
        borderColor={borderColor}
      >
        <Text color={textColor} fontSize="22px" fontWeight="700">
          Activity Audit Trail
        </Text>
      </Flex>

      <Box overflowX="auto">
        <Table variant="simple" color="gray.500" mt="12px">
          <Thead>
            {table.getHeaderGroups().map((headerGroup) => (
              <Tr key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <Th
                    key={header.id}
                    borderColor={borderColor}
                    cursor="pointer"
                    onClick={header.column.getToggleSortingHandler()}
                  >
                    <Flex justify="space-between" align="center">
                      <Text fontSize="12px" color="gray.400" fontWeight="700">
                        {flexRender(header.column.columnDef.header, header.getContext())}
                      </Text>
                    </Flex>
                  </Th>
                ))}
              </Tr>
            ))}
          </Thead>
          <Tbody>
            {table.getRowModel().rows.map((row) => (
              <Tr key={row.id} _hover={{ bg: useColorModeValue('gray.50', 'whiteAlpha.50') }} transition="0.2s">
                {row.getVisibleCells().map((cell) => (
                  <Td key={cell.id} borderColor="transparent" py="16px">
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </Td>
                ))}
              </Tr>
            ))}
          </Tbody>
        </Table>
      </Box>
    </Box>
  );
}
