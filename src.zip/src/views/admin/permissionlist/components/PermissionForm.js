import React, { useState, useEffect } from 'react';
import {
  Button,
  FormControl,
  FormLabel,
  Input,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Stack,
  useToast,
} from '@chakra-ui/react';
import { permissionService } from 'services/api';

const PermissionForm = ({ isOpen, onClose, permission, onSave }) => {
  const [formData, setFormData] = useState({ name: '', description: '' });
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  useEffect(() => {
    if (isOpen) {
      if (permission) {
        setFormData(permission);
      } else {
        setFormData({ name: '', description: '' });
      }
    }
  }, [isOpen, permission]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      if (permission) {
        await permissionService.edit(formData);
      } else {
        await permissionService.add(formData);
      }

      toast({
        title: permission ? "Permission updated" : "Permission created",
        status: "success",
        duration: 2000,
      });

      const updatedList = await permissionService.getAll();
      onSave(updatedList);
      onClose();
    } catch (error) {
      toast({
        title: "Action failed",
        description: error.message,
        status: "error",
        duration: 4000,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered size="md">
      <ModalOverlay backdropFilter="blur(4px)" />
      <ModalContent borderRadius="2xl" p="4">
        <ModalHeader fontSize="2xl" fontWeight="700">
          {permission ? 'Edit System Permission' : 'Create New Permission'}
        </ModalHeader>
        <ModalCloseButton borderRadius="full" />
        <ModalBody>
          <Stack spacing="4">
            <FormControl isRequired>
              <FormLabel fontWeight="600">Permission Name</FormLabel>
              <Input
                name="name"
                variant="auth"
                placeholder="e.g. read_logs"
                value={formData.name}
                onChange={handleChange}
                isDisabled={!!permission}
              />
            </FormControl>
            <FormControl isRequired>
              <FormLabel fontWeight="600">Access Description</FormLabel>
              <Input
                name="description"
                variant="auth"
                placeholder="What does this permit?"
                value={formData.description}
                onChange={handleChange}
              />
            </FormControl>
          </Stack>
        </ModalBody>
        <ModalFooter gap="3">
          <Button variant="ghost" onClick={onClose} fontWeight="500">
            Cancel
          </Button>
          <Button
            variant="brand"
            onClick={handleSubmit}
            isLoading={loading}
            fontWeight="600"
            px="8"
          >
            {permission ? 'Update Permission' : 'Create Permission'}
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default PermissionForm;