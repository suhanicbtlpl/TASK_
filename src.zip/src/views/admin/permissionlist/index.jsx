import React, { useState, useEffect } from "react";
import { Box, Text, Flex, useColorModeValue } from "@chakra-ui/react";
import TablePermissionList from "views/admin/permissionlist/components/TablePermissionList";
import Card from "components/card/Card.js";
import { permissionService } from "services/api";
import { createColumnHelper } from "@tanstack/react-table";

const columnHelper = createColumnHelper();

export default function PermissionsList() {
  const [permissionsData, setPermissionsData] = useState([]);
  const [loading, setLoading] = useState(true);

  const textColor = useColorModeValue('secondaryGray.900', 'white');

  const columnsData = [
    columnHelper.accessor('name', {
      id: 'name',
      header: 'NAME',
      cell: (info) => (
        <Text color={textColor} fontSize="sm" fontWeight="700">
          {info.getValue()}
        </Text>
      ),
    }),
    columnHelper.accessor('description', {
      id: 'description',
      header: 'DESCRIPTION',
      cell: (info) => (
        <Text color={textColor} fontSize="sm" fontWeight="600">
          {info.getValue()}
        </Text>
      ),
    })
  ];

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await permissionService.getAll();
        setPermissionsData(data);
      } catch (err) {
        console.error("Error fetching permissions:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleSavePermission = (updatedList) => {
    setPermissionsData(updatedList);
  };

  return (
    <Box pt={{ base: "130px", md: "80px", xl: "80px" }}>
      <Card px="0px" pb="20px">
        {loading ? (
          <Flex justify="center" align="center" minH="200px">
            <Text fontSize="xl" fontWeight="600" color="gray.400">
              Loading Permissions...
            </Text>
          </Flex>
        ) : (
          <TablePermissionList
            tableData={permissionsData}
            columnsData={columnsData}
            onSave={handleSavePermission}
          />
        )}
      </Card>
    </Box>
  );
}
