import React, { useState, useEffect } from 'react';
import {
  Button,
  FormControl,
  FormLabel,
  Input,
  Select,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Center,
  Spinner,
  Checkbox,
  CheckboxGroup,
  Stack,
  useToast,
} from '@chakra-ui/react';
import { userService, roleService } from 'services/api';

const UserForm = ({ isOpen, onClose, user, onSave }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: '',
    permissions: []
  });
  const [loading, setLoading] = useState(false);
  const [rolesList, setRolesList] = useState([]);
  const [permissionsList, setPermissionsList] = useState([]);
  const toast = useToast();

  useEffect(() => {
    const fetchInitialData = async () => {
      try {
        const roles = await roleService.getAll();
        setRolesList(roles);
      } catch (err) {
        toast({
          title: "Error fetching roles",
          status: "error",
          duration: 3000,
          isClosable: true,
        });
      }
    };

    if (isOpen) {
      fetchInitialData();
      if (user) {
        setFormData({ ...user, password: '' });
      } else {
        setFormData({ name: '', email: '', password: '', role: '', permissions: [] });
      }
    }
  }, [isOpen, user, toast]);

  useEffect(() => {
    if (formData.role && rolesList.length > 0) {
      const selectedRole = rolesList.find((role) => role.name === formData.role);
      if (selectedRole) {
        setPermissionsList(selectedRole.permissions);
        setFormData((prev) => ({
          ...prev,
          permissions: selectedRole.permissions,
        }));
      }
    } else {
      setPermissionsList([]);
    }
  }, [formData.role, rolesList]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      let result;
      if (user) {
        result = await userService.edit(formData);
      } else {
        result = await userService.add(formData);
      }

      toast({
        title: user ? "User updated" : "User added",
        status: "success",
        duration: 2000,
      });

      // Fetch fresh list after save
      const updatedList = await userService.getAll();
      onSave(updatedList);
      onClose();
    } catch (error) {
      toast({
        title: "Action failed",
        description: error.message,
        status: "error",
        duration: 4000,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered size="md">
      <ModalOverlay backdropFilter="blur(4px)" />
      <ModalContent borderRadius="2xl" p="4">
        <ModalHeader fontSize="2xl" fontWeight="700">
          {user ? 'Edit User Profile' : 'Create New User'}
        </ModalHeader>
        <ModalCloseButton borderRadius="full" />
        <ModalBody>
          {loading && !formData.name ? (
            <Center h="200px">
              <Spinner size="xl" color="brand.500" thickness="4px" />
            </Center>
          ) : (
            <Stack spacing="4">
              <FormControl isRequired>
                <FormLabel fontWeight="600">Full Name</FormLabel>
                <Input
                  name="name"
                  variant="auth"
                  placeholder="John Doe"
                  value={formData.name}
                  onChange={handleChange}
                />
              </FormControl>
              <FormControl isRequired>
                <FormLabel fontWeight="600">Email Address</FormLabel>
                <Input
                  name="email"
                  variant="auth"
                  type="email"
                  placeholder="john@example.com"
                  value={formData.email}
                  onChange={handleChange}
                  isDisabled={!!user}
                />
              </FormControl>
              {!user && (
                <FormControl isRequired>
                  <FormLabel fontWeight="600">Security Password</FormLabel>
                  <Input
                    name="password"
                    variant="auth"
                    placeholder="Min. 8 characters"
                    type="password"
                    value={formData.password}
                    onChange={handleChange}
                  />
                </FormControl>
              )}
              <FormControl isRequired>
                <FormLabel fontWeight="600">Assigned Role</FormLabel>
                <Select
                  name="role"
                  variant="auth"
                  placeholder="Select a role"
                  value={formData.role}
                  onChange={handleChange}
                >
                  {rolesList.map((role) => (
                    <option key={role._id} value={role.name}>
                      {role.name}
                    </option>
                  ))}
                </Select>
              </FormControl>
              {permissionsList.length > 0 && (
                <FormControl>
                  <FormLabel fontWeight="600">Automatic Permissions</FormLabel>
                  <CheckboxGroup colorScheme="brand" value={formData.permissions}>
                    <Stack spacing={2} direction="row" wrap="wrap">
                      {permissionsList.map((permission, idx) => (
                        <Checkbox key={idx} value={permission} isDisabled>
                          {permission}
                        </Checkbox>
                      ))}
                    </Stack>
                  </CheckboxGroup>
                </FormControl>
              )}
            </Stack>
          )}
        </ModalBody>
        <ModalFooter gap="3">
          <Button variant="ghost" onClick={onClose} fontWeight="500">
            Cancel
          </Button>
          <Button
            variant="brand"
            onClick={handleSubmit}
            isLoading={loading}
            fontWeight="600"
            px="8"
          >
            {user ? 'Save Changes' : 'Create User'}
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default UserForm;
