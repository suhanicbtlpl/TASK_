import React, { useEffect, useState, useCallback } from 'react';
import {
  Box,
  Button,
  Flex,
  Table,
  Tbody,
  Td,
  Text,
  Th,
  Thead,
  Tr,
  useColorModeValue,
  useDisclosure,
  Icon,
  HStack,
  Tooltip,
} from '@chakra-ui/react';
import {
  flexRender,
  getCoreRowModel,
  getSortedRowModel,
  useReactTable,
} from '@tanstack/react-table';
import { MdEdit, MdDelete, MdPersonAdd } from 'react-icons/md';
import UserForm from './UserForm';
import { userService } from 'services/api';

export default function TableUserList({ tableData, columnsData }) {
  const [sorting, setSorting] = useState([]);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [selectedUser, setSelectedUser] = useState(null);
  const [data, setData] = useState(tableData);
  const [currentUser, setCurrentUser] = useState(null);

  const textColor = useColorModeValue('secondaryGray.900', 'white');
  const borderColor = useColorModeValue('gray.200', 'whiteAlpha.100');
  const cardShadow = useColorModeValue(
    '0px 18px 40px rgba(112, 144, 176, 0.12)',
    'unset'
  );

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const user = await userService.getCurrent();
        setCurrentUser(user);
      } catch (err) {
        console.error('Failed to fetch current user', err);
      }
    };
    fetchUser();
  }, []);

  const handleEdit = (user) => {
    setSelectedUser(user);
    onOpen();
  };

  const handleAdd = () => {
    setSelectedUser(null);
    onOpen();
  };

  const handleDelete = async (user) => {
    if (!window.confirm(`Are you sure you want to delete ${user.name}?`)) return;

    try {
      await userService.delete({ name: user.name, email: user.email });
      const updatedData = data.filter((u) => u.email !== user.email);
      setData(updatedData);
      localStorage.setItem('userList', JSON.stringify(updatedData));
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  const actionsColumn = {
    id: 'actions',
    header: () => (
      <Text fontSize="12px" color="gray.400" fontWeight="700">ACTIONS</Text>
    ),
    cell: ({ row }) => {
      const isViewer = currentUser?.role?.toLowerCase() === 'viewer';
      const isDev = currentUser?.role?.toLowerCase() === 'dev';

      if (isViewer) return null;

      return (
        <HStack spacing="2">
          <Tooltip label="Edit User">
            <Button
              variant="action"
              size="sm"
              px="0"
              onClick={() => handleEdit(row.original)}
            >
              <Icon as={MdEdit} />
            </Button>
          </Tooltip>
          {!isDev && (
            <Tooltip label="Delete User">
              <Button
                colorScheme="red"
                variant="light"
                size="sm"
                px="0"
                onClick={() => handleDelete(row.original)}
              >
                <Icon as={MdDelete} />
              </Button>
            </Tooltip>
          )}
        </HStack>
      );
    },
  };

  const table = useReactTable({
    data,
    columns: currentUser?.role?.toLowerCase() === 'viewer' ? columnsData : [...columnsData, actionsColumn],
    state: { sorting },
    onSortingChange: setSorting,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
  });

  return (
    <Box>
      <Flex
        align="center"
        justify="space-between"
        w="100%"
        px="25px"
        py="20px"
        borderBottom="1px solid"
        borderColor={borderColor}
      >
        <Text color={textColor} fontSize="22px" fontWeight="700" lineHeight="100%">
          User Management
        </Text>
        {currentUser?.role?.toLowerCase() !== 'viewer' && (
          <Button
            leftIcon={<Icon as={MdPersonAdd} />}
            variant="brand"
            fontWeight="500"
            borderRadius="70px"
            onClick={handleAdd}
          >
            Add User
          </Button>
        )}
      </Flex>

      <Box overflowX="auto">
        <Table variant="simple" color="gray.500" mt="12px">
          <Thead>
            {table.getHeaderGroups().map((headerGroup) => (
              <Tr key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <Th
                    key={header.id}
                    pe="10px"
                    borderColor={borderColor}
                    cursor="pointer"
                    onClick={header.column.getToggleSortingHandler()}
                  >
                    <Flex justify="space-between" align="center">
                      <Text
                        fontSize="12px"
                        color="gray.400"
                        fontWeight="700"
                      >
                        {flexRender(header.column.columnDef.header, header.getContext())}
                      </Text>
                    </Flex>
                  </Th>
                ))}
              </Tr>
            ))}
          </Thead>
          <Tbody>
            {table.getRowModel().rows.map((row) => (
              <Tr key={row.id} _hover={{ bg: useColorModeValue('gray.50', 'whiteAlpha.50') }} transition="0.2s">
                {row.getVisibleCells().map((cell) => (
                  <Td key={cell.id} borderColor="transparent" py="12px">
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </Td>
                ))}
              </Tr>
            ))}
          </Tbody>
        </Table>
      </Box>

      <UserForm
        isOpen={isOpen}
        onClose={onClose}
        user={selectedUser}
        onSave={(updatedList) => setData(updatedList)}
      />
    </Box>
  );
}
