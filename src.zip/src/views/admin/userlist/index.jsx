import React, { useState, useEffect } from "react";
import { Box, Text, Flex, useColorModeValue, Badge } from "@chakra-ui/react";
import TableUserList from "views/admin/userlist/components/TableUserList";
import Card from "components/card/Card.js";
import { userService } from "services/api";
import { createColumnHelper } from "@tanstack/react-table";

const columnHelper = createColumnHelper();

export default function UserList() {
  const [usersData, setUsersData] = useState([]);
  const [loading, setLoading] = useState(true);

  const textColor = useColorModeValue('secondaryGray.900', 'white');
  const textColorSecondary = 'gray.400';

  const columnsData = [
    columnHelper.accessor('name', {
      id: 'name',
      header: 'NAME',
      cell: (info) => (
        <Text color={textColor} fontSize="sm" fontWeight="700">
          {info.getValue()}
        </Text>
      ),
    }),
    columnHelper.accessor('email', {
      id: 'email',
      header: 'EMAIL',
      cell: (info) => (
        <Text color={textColorSecondary} fontSize="sm" fontWeight="500">
          {info.getValue()}
        </Text>
      ),
    }),
    columnHelper.accessor('role', {
      id: 'role',
      header: 'ROLE',
      cell: (info) => {
        const role = info.getValue();
        let colorScheme = 'blue';
        if (role === 'Admin') colorScheme = 'purple';
        if (role === 'Viewer') colorScheme = 'teal';
        return (
          <Badge colorScheme={colorScheme} borderRadius="8px" px="2">
            {role}
          </Badge>
        );
      },
    }),
    columnHelper.accessor('permissions', {
      id: 'permissions',
      header: 'PERMISSIONS',
      cell: (info) => (
        <Flex direction="row" wrap="wrap" gap="2">
          {info.getValue()?.map((permission, index) => (
            <Badge key={index} variant="subtle" colorScheme="gray" borderRadius="4px" fontSize="20px">
              {permission}
            </Badge>
          ))}
        </Flex>
      ),
    })
  ];

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await userService.getAll();
        setUsersData(data);
      } catch (err) {
        console.error('Failed to fetch users', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <Box pt={{ base: "130px", md: "80px", xl: "80px" }}>
      <Card px="0px" pb="20px">
        {loading ? (
          <Flex justify="center" align="center" minH="200px">
            <Text fontSize="xl" fontWeight="600" color={textColorSecondary}>
              Securing connection...
            </Text>
          </Flex>
        ) : (
          <TableUserList tableData={usersData} columnsData={columnsData} />
        )}
      </Card>
    </Box>
  );
}
