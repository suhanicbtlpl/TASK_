import React, { useState, useEffect } from 'react';
import {
  Button,
  FormControl,
  FormLabel,
  Input,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Checkbox,
  CheckboxGroup,
  Stack,
  useToast,
  Text,
} from '@chakra-ui/react';
import { roleService, permissionService } from 'services/api';

export default function RoleForm({ isOpen, onClose, role, onSave }) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    permissions: []
  });
  const [permissionsList, setPermissionsList] = useState([]);
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  useEffect(() => {
    const fetchPermissions = async () => {
      try {
        const perms = await permissionService.getAll();
        setPermissionsList(perms);
      } catch (err) {
        console.error("Failed to fetch permissions", err);
      }
    };

    if (isOpen) {
      fetchPermissions();
      if (role) {
        setFormData(role);
      } else {
        setFormData({ name: '', description: '', permissions: [] });
      }
    }
  }, [isOpen, role]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handlePermissionsChange = (selectedPermissions) => {
    setFormData({ ...formData, permissions: selectedPermissions });
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      if (role) {
        await roleService.edit(formData);
      } else {
        await roleService.add(formData);
      }

      toast({
        title: role ? "Role updated" : "Role created",
        status: "success",
        duration: 2000,
      });

      const updatedList = await roleService.getAll();
      onSave(updatedList);
      onClose();
    } catch (error) {
      toast({
        title: "Action failed",
        description: error.message,
        status: "error",
        duration: 4000,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered size="md">
      <ModalOverlay backdropFilter="blur(4px)" />
      <ModalContent borderRadius="2xl" p="4">
        <ModalHeader fontSize="2xl" fontWeight="700">
          {role ? 'Edit System Role' : 'Create New Role'}
        </ModalHeader>
        <ModalCloseButton borderRadius="full" />
        <ModalBody>
          <Stack spacing="4">
            <FormControl isRequired>
              <FormLabel fontWeight="600">Role Name</FormLabel>
              <Input
                name="name"
                variant="auth"
                placeholder="e.g. Editor"
                value={formData.name}
                onChange={handleChange}
                isDisabled={!!role}
              />
            </FormControl>
            <FormControl isRequired>
              <FormLabel fontWeight="600">Short Description</FormLabel>
              <Input
                name="description"
                variant="auth"
                placeholder="Describe role capabilities"
                value={formData.description}
                onChange={handleChange}
              />
            </FormControl>
            <FormControl>
              <FormLabel fontWeight="600">Select Permissions</FormLabel>
              <Text fontSize="xs" color="gray.400" mb="2">
                Choose the actions allowed for this role
              </Text>
              <CheckboxGroup
                colorScheme="brand"
                value={formData.permissions}
                onChange={handlePermissionsChange}
              >
                <Stack direction="row" wrap="wrap" spacing="4">
                  {permissionsList.map((permission, idx) => (
                    <Checkbox key={idx} value={permission.name}>
                      {permission.name}
                    </Checkbox>
                  ))}
                </Stack>
              </CheckboxGroup>
            </FormControl>
          </Stack>
        </ModalBody>
        <ModalFooter gap="3">
          <Button variant="ghost" onClick={onClose} fontWeight="500">
            Cancel
          </Button>
          <Button
            variant="brand"
            onClick={handleSubmit}
            isLoading={loading}
            fontWeight="600"
            px="8"
          >
            {role ? 'Update Role' : 'Create Role'}
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}
