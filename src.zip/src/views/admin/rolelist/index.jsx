import React, { useState, useEffect } from "react";
import { Box, Text, Flex, useColorModeValue, Badge } from "@chakra-ui/react";
import TableRoleList from "views/admin/rolelist/components/TableRoleList";
import Card from "components/card/Card.js";
import { roleService } from "services/api";
import { createColumnHelper } from "@tanstack/react-table";

const columnHelper = createColumnHelper();

export default function RolesList() {
  const [rolesData, setRolesData] = useState([]);
  const [loading, setLoading] = useState(true);

  const textColor = useColorModeValue('secondaryGray.900', 'white');
  const textColorSecondary = 'gray.400';

  const columnsData = [
    columnHelper.accessor('name', {
      id: 'name',
      header: 'NAME',
      cell: (info) => (
        <Text color={textColor} fontSize="sm" fontWeight="700">
          {info.getValue()}
        </Text>
      ),
    }),
    columnHelper.accessor('description', {
      id: 'description',
      header: 'DESCRIPTION',
      cell: (info) => (
        <Text color={textColorSecondary} fontSize="sm" fontWeight="500">
          {info.getValue()}
        </Text>
      ),
    }),
    columnHelper.accessor('permissions', {
      id: 'permissions',
      header: 'PERMISSIONS',
      cell: (info) => (
        <Flex direction="row" wrap="wrap" gap="2">
          {info.getValue()?.map((permission, index) => (
            <Badge key={index} variant="solid" colorScheme="gray" borderRadius="full" fontSize="2xs" px="2">
              {permission}
            </Badge>
          ))}
        </Flex>
      ),
    }),
  ];

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await roleService.getAll();
        setRolesData(data);
      } catch (err) {
        console.error('Failed to fetch roles', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  return (
    <Box pt={{ base: "130px", md: "80px", xl: "80px" }}>
      <Card px="0px" pb="20px">
        {loading ? (
          <Flex justify="center" align="center" minH="200px">
            <Text fontSize="xl" fontWeight="600" color={textColorSecondary}>
              Loading Roles...
            </Text>
          </Flex>
        ) : (
          <TableRoleList tableData={rolesData} columnsData={columnsData} />
        )}
      </Card>
    </Box>
  );
}
