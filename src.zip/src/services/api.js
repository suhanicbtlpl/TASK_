const BASE_URL = process.env.REACT_APP_SERVER_URL || 'http://localhost:3001';

const handleResponse = async (response) => {
    if (!response.ok) {
        const error = await response.json().catch(() => ({ message: response.statusText }));
        throw new Error(error.message || `HTTP error! status: ${response.status}`);
    }
    return response.json();
};

const api = {
    get: (url) => fetch(`${BASE_URL}${url}`, {
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' }
    }).then(handleResponse),

    post: (url, data) => fetch(`${BASE_URL}${url}`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    }).then(handleResponse),

    put: (url, data) => fetch(`${BASE_URL}${url}`, {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    }).then(handleResponse),

    delete: (url, data) => fetch(`${BASE_URL}${url}`, {
        method: 'DELETE',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    }).then(handleResponse),
};

export const userService = {
    getCurrent: () => api.get('/api/user'),
    getAll: () => api.get('/api/user/all'),
    add: (data) => api.post('/api/user/add', data),
    edit: (data) => api.put('/api/user/edit', data),
    delete: (data) => api.delete('/api/user/delete', data),
};

export const authService = {
    login: (credentials) => api.post('/api/auth/login', credentials),
    signup: (data) => api.post('/api/auth/signup', data),
    logout: () => api.get('/api/auth/logout'),
};

export const roleService = {
    getAll: () => api.get('/api/role'),
    add: (data) => api.post('/api/role/add', data),
    edit: (data) => api.put('/api/role/edit', data),
    delete: (data) => api.delete('/api/role/delete', data),
};

export const permissionService = {
    getAll: () => api.get('/api/permission'),
    add: (data) => api.post('/api/permission/add', data),
    edit: (data) => api.put('/api/permission/edit', data),
    delete: (data) => api.delete('/api/permission/delete', data),
};

export const logService = {
    getAll: () => api.get('/api/log'),
};

export default api;
