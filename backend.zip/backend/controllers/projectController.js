const Project = require('../models/Project');

// @desc    Get all projects
// @route   GET /api/projects
// @access  Private
const getProjects = async (req, res) => {
    const projects = await Project.find({}).populate('assignedStaff', 'name email').populate('createdBy', 'name');
    res.json(projects);
};

// @desc    Create new project
// @route   POST /api/projects
// @access  Private
const createProject = async (req, res) => {
    const { projectName, assignedStaff } = req.body;

    const project = await Project.create({
        projectName,
        assignedStaff,
        totalAssignedStaff: assignedStaff.length,
        createdBy: req.user._id
    });

    if (project) {
        res.status(201).json(project);
    } else {
        res.status(400).json({ message: 'Invalid project data' });
    }
};

// @desc    Update project
// @route   PUT /api/projects/:id
// @access  Private
const updateProject = async (req, res) => {
    const project = await Project.findById(req.params.id);

    if (project) {
        project.projectName = req.body.projectName || project.projectName;
        project.assignedStaff = req.body.assignedStaff || project.assignedStaff;
        project.totalAssignedStaff = project.assignedStaff.length;

        const updatedProject = await project.save();
        res.json(updatedProject);
    } else {
        res.status(404).json({ message: 'Project not found' });
    }
};

// @desc    Delete project
// @route   DELETE /api/projects/:id
// @access  Private
const deleteProject = async (req, res) => {
    const project = await Project.findById(req.params.id);
    if (project) {
        await project.deleteOne();
        res.json({ message: 'Project removed' });
    } else {
        res.status(404).json({ message: 'Project not found' });
    }
};

module.exports = { getProjects, createProject, updateProject, deleteProject };
