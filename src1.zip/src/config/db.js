const mongoose = require('mongoose');
const seedDatabase = require('../../seedData');

const connectDB = async () => {
    const DB = process.env.MONGODB_URI;
    try {
        await mongoose.connect(DB);
        console.log("Successfully connected to database!!");
        // Automatically seed database with dummy data if empty
        await seedDatabase();
    } catch (err) {
        console.error("Database connection error:", err);
        process.exit(1);
    }
};

module.exports = connectDB;
