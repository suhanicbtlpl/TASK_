const passport = require('passport');
const User = require('../models/user');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const GitHubStrategy = require('passport-github2').Strategy;

const configurePassport = () => {
    // Local Strategy (via passport-local-mongoose)
    passport.use(User.createStrategy({ usernameField: 'email' }));

    // Google Strategy
    if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
        passport.use(new GoogleStrategy({
            clientID: process.env.GOOGLE_CLIENT_ID,
            clientSecret: process.env.GOOGLE_CLIENT_SECRET,
            callbackURL: process.env.CALLBACK_URL_ORIGIN + "/api/auth/google/redirect"
        },
            async (accessToken, refreshToken, profile, cb) => {
                User.findOrCreate({ googleId: profile.id }, { name: profile.displayName, email: profile.emails[0].value, provider: 'google' }, (error, user) => {
                    return cb(error, user);
                });
            }));
    }

    // GitHub Strategy
    if (process.env.GITHUB_CLIENT_ID && process.env.GITHUB_CLIENT_SECRET) {
        passport.use(new GitHubStrategy({
            clientID: process.env.GITHUB_CLIENT_ID,
            clientSecret: process.env.GITHUB_CLIENT_SECRET,
            callbackURL: process.env.CALLBACK_URL_ORIGIN + "/api/auth/github/redirect",
            passReqToCallback: true,
            scope: ['user:email'],
        },
            async (req, accessToken, refreshToken, profile, done) => {
                User.findOrCreate({ githubId: profile.id }, { email: profile.emails[0].value, name: profile.displayName, provider: 'github' }, function (err, user) {
                    return done(err, user);
                });
            }));
    }

    passport.serializeUser((user, done) => {
        done(null, user.id);
    });

    passport.deserializeUser(async (id, done) => {
        try {
            const user = await User.findById(id).exec();
            done(null, user);
        } catch (error) {
            done(error, null);
        }
    });
};

module.exports = configurePassport;
