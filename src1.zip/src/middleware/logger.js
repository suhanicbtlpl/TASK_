const Log = require('../models/log');

const createActivityLog = async (req, action) => {
    try {
        const user = req.user;
        if (!user) return;

        const newLog = new Log({
            name: user.name,
            email: user.email,
            role: user.role,
            timestamp: new Date().toISOString().slice(0, 19).replace('T', ' '),
            action: action
        });
        await newLog.save();
    } catch (error) {
        console.error("Failed to save activity log:", error);
    }
};

module.exports = { createActivityLog };
