const Permission = require('../models/permission');
const { createActivityLog } = require('../middleware/logger');

exports.getAllPermissions = async (req, res) => {
    try {
        const permissions = await Permission.find();
        res.status(200).json(permissions);
    } catch (error) {
        res.status(500).json({ message: "Error fetching permissions", error });
    }
};

exports.addPermission = async (req, res) => {
    try {
        const { name, description } = req.body;
        const existingPerm = await Permission.findOne({ name });
        if (existingPerm) {
            return res.status(400).json({ message: "Perm already exists" });
        }

        const newPerm = new Permission({ name, description });
        await newPerm.save();

        await createActivityLog(req, `added new permission: ${name}`);
        res.status(201).json({ message: "Permission created successfully", newPerm });
    } catch (error) {
        res.status(500).json({ message: "Error adding permission", error });
    }
};

exports.deletePermission = async (req, res) => {
    try {
        const { name } = req.body;
        const permission = await Permission.findOneAndDelete({ name });

        if (!permission) {
            return res.status(404).json({ message: "permission not found" });
        }

        await createActivityLog(req, `delete user permission: ${name}`);
        res.status(200).json({ message: `Perm '${name}' deleted successfully`, name: permission });
    } catch (error) {
        res.status(500).json({ message: "Error deleting Perm", error });
    }
};

exports.editPermission = async (req, res) => {
    try {
        const { name, description } = req.body;
        const updatedPerm = await Permission.findOneAndUpdate(
            { name },
            { description },
            { new: true, runValidators: true }
        );

        if (!updatedPerm) {
            return res.status(404).json({ message: "Permission not found" });
        }

        await createActivityLog(req, `edit permission: ${name}`);
        res.status(200).json({ message: "Perm updated successfully", name: updatedPerm });
    } catch (error) {
        res.status(500).json({ message: "Error updating perm", error });
    }
};
