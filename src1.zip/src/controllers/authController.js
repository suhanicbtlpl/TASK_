const passport = require('passport');
const User = require('../models/user');

exports.signup = async (req, res) => {
    const { email, password, name, role, permissions } = req.body;
    try {
        const foundUser = await User.findOne({ email });
        if (foundUser) {
            return res.status(401).json({ message: 'The email already exists!' });
        }

        const newUser = new User({ email, name, role, permissions, provider: 'local' });
        User.register(newUser, password, (err, user) => {
            if (err) {
                console.error(err);
                return res.status(401).json(err);
            }
            passport.authenticate('local')(req, res, () => {
                const userObj = user.toObject();
                delete userObj.salt;
                delete userObj.hash;
                res.status(200).json({ message: 'User Authenticated!', userObj });
            });
        });
    } catch (error) {
        res.status(500).json({ message: 'Signup failed', error });
    }
};

exports.login = (req, res, next) => {
    passport.authenticate('local', async (err, user, info) => {
        if (err) return res.status(500).json({ message: 'An error occurred during authentication.' });
        if (!user) return res.status(401).json({ message: 'Invalid email or password.' });

        req.logIn(user, async (loginErr) => {
            if (loginErr) return res.status(500).json({ message: 'An error occurred during login.' });

            try {
                const foundUser = await User.findById(user._id).exec();
                return res.status(200).json({
                    message: 'Login successful.',
                    user: {
                        id: foundUser._id,
                        email: foundUser.email,
                        name: foundUser.name,
                        role: foundUser.role,
                    },
                });
            } catch (error) {
                return res.status(500).json({ message: 'An error occurred while retrieving user details.' });
            }
        });
    })(req, res, next);
};

exports.logout = (req, res) => {
    req.logout((err) => {
        if (err) return res.status(500).json({ message: "Logout failed" });
        res.status(200).json({ message: "Successfully logged out" });
    });
};

exports.googleAuth = passport.authenticate('google', { scope: ['profile', 'email'] });

exports.googleCallback = (req, res) => {
    res.redirect(process.env.CLIENT_URL);
};

exports.githubAuth = passport.authenticate('github');

exports.githubCallback = (req, res) => {
    res.redirect(process.env.CLIENT_URL);
};
