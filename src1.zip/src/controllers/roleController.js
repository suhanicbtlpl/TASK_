const Role = require('../models/role');
const { createActivityLog } = require('../middleware/logger');

exports.getAllRoles = async (req, res) => {
    try {
        const roles = await Role.find();
        res.status(200).json(roles);
    } catch (error) {
        res.status(500).json({ message: "Error fetching roles", error });
    }
};

exports.addRole = async (req, res) => {
    try {
        const { name, description, permissions } = req.body;
        const existingRole = await Role.findOne({ name });

        if (existingRole) {
            return res.status(400).json({ message: "Role already exists" });
        }

        const newRole = new Role({ name, description, permissions });
        await newRole.save();

        await createActivityLog(req, `added new role: ${name}`);
        res.status(201).json({ message: "Role created successfully", newRole });
    } catch (error) {
        res.status(500).json({ message: "Error adding role", error });
    }
};

exports.deleteRole = async (req, res) => {
    try {
        const { name } = req.body;
        const role = await Role.findOneAndDelete({ name });

        if (!role) {
            return res.status(404).json({ message: "Role not found" });
        }

        await createActivityLog(req, `deleted role: ${name}`);
        res.status(200).json({ message: `Role '${name}' deleted successfully`, role });
    } catch (error) {
        res.status(500).json({ message: "Error deleting role", error });
    }
};

exports.editRole = async (req, res) => {
    try {
        const { name, description, permissions } = req.body;
        const updatedRole = await Role.findOneAndUpdate(
            { name },
            { description, permissions },
            { new: true, runValidators: true }
        );

        if (!updatedRole) {
            return res.status(404).json({ message: "Role not found" });
        }

        await createActivityLog(req, `update role: ${name}`);
        res.status(200).json({ message: "Role updated successfully", role: updatedRole });
    } catch (error) {
        res.status(500).json({ message: "Error updating role", error });
    }
};
