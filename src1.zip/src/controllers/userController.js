const User = require('../models/user');
const { createActivityLog } = require('../middleware/logger');

exports.getCurrentUser = (req, res) => {
    if (req.isAuthenticated()) {
        res.status(200).json(req.user);
    } else {
        res.status(401).json({ message: 'Authentication Error!' });
    }
};

exports.getAllUsers = async (req, res) => {
    try {
        const users = await User.find();
        res.status(200).json(users);
    } catch (error) {
        res.status(500).json({ message: "There was error fetching users", error });
    }
};

exports.addUser = async (req, res) => {
    try {
        const { name, email, password, role, permissions } = req.body;
        const existingUser = await User.findOne({ email });

        if (existingUser) {
            return res.status(400).json({ message: "User already exists" });
        }

        const newUser = new User({
            name,
            email,
            role,
            permissions,
            provider: "admin-panel"
        });

        User.register(newUser, password, async (err, registeredUser) => {
            if (err) {
                res.status(500).json({ message: "Error registering user", error: err });
            } else {
                await createActivityLog(req, `added new user: ${name}`);
                res.status(201).json({ message: "User created successfully", user: registeredUser });
            }
        });
    } catch (error) {
        res.status(500).json({ message: "Error adding user", error });
    }
};

exports.deleteUser = async (req, res) => {
    try {
        const { name, email } = req.body;
        const foundUser = await User.findOneAndDelete({ email });

        if (!foundUser) {
            return res.status(404).json({ message: "User not found" });
        }

        await createActivityLog(req, `deleted User: ${name} and ${email}`);
        res.status(200).json({ message: `User '${name}' deleted successfully`, user: foundUser });
    } catch (error) {
        res.status(500).json({ message: "Error deleting User", error });
    }
};

exports.editUser = async (req, res) => {
    try {
        const { name, email, role, permissions } = req.body;
        const updatedUser = await User.findOneAndUpdate(
            { email },
            { name, role, permissions },
            { new: true, runValidators: true }
        );

        if (!updatedUser) {
            return res.status(404).json({ message: "user not found" });
        }

        await createActivityLog(req, `updated User: ${name} and ${email}`);
        res.status(200).json({ message: "User updated successfully", user: updatedUser });
    } catch (error) {
        res.status(500).json({ message: "User update Failed!", error });
    }
};
