const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

router.get('/', userController.getCurrentUser);
router.get('/all', userController.getAllUsers);
router.post('/add', userController.addUser);
router.delete('/delete', userController.deleteUser);
router.put('/edit', userController.editUser);

module.exports = router;
