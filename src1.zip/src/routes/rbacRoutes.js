const express = require('express');
const roleRouter = express.Router();
const permissionRouter = express.Router();
const roleController = require('../controllers/roleController');
const permissionController = require('../controllers/permissionController');

// Role Routes
roleRouter.get('/', roleController.getAllRoles);
roleRouter.post('/add', roleController.addRole);
roleRouter.delete('/delete', roleController.deleteRole);
roleRouter.put('/edit', roleController.editRole);

// Permission Routes
permissionRouter.get('/', permissionController.getAllPermissions);
permissionRouter.post('/add', permissionController.addPermission);
permissionRouter.delete('/delete', permissionController.deletePermission);
permissionRouter.put('/edit', permissionController.editPermission);

module.exports = { roleRouter, permissionRouter };
