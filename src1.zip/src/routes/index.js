const express = require('express');
const router = express.Router();

const authRoutes = require('./authRoutes');
const userRoutes = require('./userRoutes');
const logRoutes = require('./logRoutes');
const { roleRouter, permissionRouter } = require('./rbacRoutes');

router.use('/auth', authRoutes);
router.use('/user', userRoutes);
router.use('/log', logRoutes);
router.use('/role', roleRouter);
router.use('/permission', permissionRouter);

// Legacy/Compatibility Root Routes (if needed by existing client)
const authController = require('../controllers/authController');
router.post('/login', authController.login);
router.post('/signup', authController.signup);
router.get('/logout', authController.logout);

module.exports = router;
