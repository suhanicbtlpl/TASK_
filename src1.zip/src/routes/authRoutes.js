const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const passport = require('passport');

router.post('/signup', authController.signup);
router.post('/login', authController.login);
router.get('/logout', authController.logout);

// Google OAuth
router.get('/google', authController.googleAuth);
router.get('/google/redirect', passport.authenticate('google', { failureRedirect: '/api/auth/fail' }), authController.googleCallback);

// GitHub OAuth
router.get('/github', authController.githubAuth);
router.get('/github/redirect', passport.authenticate('github', { failureRedirect: '/api/auth/fail' }), authController.githubCallback);

router.get('/fail', (req, res) => {
    res.status(401).json({ message: 'Authentication failed' });
});

module.exports = router;
