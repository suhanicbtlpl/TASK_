const express = require('express');
const router = express.Router();
const Log = require('../models/log');

const getAllLogs = async (req, res) => {
    try {
        const logs = await Log.find();
        res.status(200).json(logs);
    } catch (error) {
        res.status(500).json({ message: "Error fetching logs", error });
    }
};

const addLog = async (req, res) => {
    try {
        const { name, email, role, timestamp, action } = req.body;
        const newLog = new Log({ name, email, role, timestamp, action });
        await newLog.save();
        res.status(201).json({ message: "log created successfully", log: newLog });
    } catch (error) {
        res.status(500).json({ message: "Error adding log", error });
    }
};

router.get('/', getAllLogs);
router.post('/add', addLog);

module.exports = router;
